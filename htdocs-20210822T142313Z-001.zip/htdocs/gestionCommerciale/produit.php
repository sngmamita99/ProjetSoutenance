<?php
session_start();


/* $use=$_SESSION['nome'];
$use=isset($_SESSION['nome'])? $_SESSION['nome']:'';

   $use=$_SESSION['nome'];
   echo $use;
 */

?>
<!DOCTYPE html>
<html lang="en">

<head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleproduit.css?t=<?php echo time();?>">
    <title>Document</title>
</head>
<body>
<section>
<form method="post" action="traitement.php">
  <div id="recherche">
<input type="search" id='rech' name="rechprod" value= "<?php if(isset($_POST['Rechercher'])) echo $_POST['Rechercher']?>" placeholder="Rechercher un produit"/>
<input type="submit" id='su' value="Rechercher un produit">
</div>
</form>
<?php 
echo"<br/>";
   // $log=$_SESSION['login'];
     // echo"je sais que tu es:$log" ;
       $connect=new PDO("mysql:host=localhost;port=3306;dbname=commercial","root","");

             if($connect)
             {
               echo"<br>";
                 echo "connection etablie<br/>";
                 if (isset($_POST['nom']) && isset($_POST["code"]) && isset($_POST["categorie"]) && isset($_POST["descript"]) && isset($_POST["quantitestock"])&& isset($_POST['prixU']))
                 {
                    
                      $nom=$_POST['nom'];
                      $code=$_POST['code'];
                      $categorie=$_POST['categorie'];
                      $description=$_POST['descript'];
                      $prixU=$_POST['prixU'];
                      $QuantiteStock=$_POST['quantitestock'];
                      echo $nom,$code,$categorie,$description,$prixU,$QuantiteStock;
                        $req="INSERT INTO produit VALUES(:code,:nom,:categorie,:description,:prixU,:QuantiteStock)";
                        $stmt=$connect->prepare($req);
                        $stmt->bindParam(':code',$code);
                        $stmt->bindParam(':nom',$nom);
                        $stmt->bindParam(':categorie',$categorie);
                        $stmt->bindParam(':description',$description);
                        $stmt->bindParam(':prixU',$prixU);
                        $stmt->bindParam(':QuantiteStock',$QuantiteStock);
                        $stmt->execute() ;         
                                     
                    
                 }
                 echo"vous etes l'utilisateur:<br/>";
                
                      
                        
                         if(isset($_FILES['photo'])){
                           $cptphotos=count($_FILES['photo']['name']);
                           for($i=0;$i<$cptphotos;$i++){
                           $extensions_ok = array( 'jpg' , 'jpeg' , 'gif' , 'png' );
   
                           $extension_fichier = strtolower( substr(strrchr($_FILES['photo']['name'][$i], '.'),1));
                           if ( in_array($extension_fichier, $extensions_ok) )
                                {
                                   echo "<p>Extension correcte du fichier</p>"; 
                                }
                        
                              $dhc=date("dmy_his",time());
                              $fic="mesphotos/".$dhc."_".$_FILES['photo']['name'][$i];
                              $result=move_uploaded_file($_FILES['photo']['tmp_name'][$i],$fic);
                              if($result){
                              echo "<p>transfert du fichier reussi</p>";
                              }

                              $url="mesphotos/".$dhc."_".$_FILES['photo']['name'][$i];
                              $codeproduit=$code;
                               
                                $req1="INSERT INTO image VALUES(:id,:url,:codeproduit)";
                                $stmt=$connect->prepare($req1);
                                $stmt->bindParam(':id',$id);
                                $stmt->bindParam(':url',$url);
                                $stmt->bindParam(':codeproduit',$codeproduit);
                                $stmt->execute() ;         
                              
                               
                       }
                     }

               

$sql2= "select * from produit order by categorie,nom" ;
$stmt=$connect->prepare($sql2);
$stmt->bindColumn('code', $code);
$stmt->bindColumn('nom', $nom);
$stmt->bindColumn('categorie', $categorie);
$stmt->bindColumn('QuantiteStock', $QuantiteStock);
$stmt->bindColumn('prixU', $prixU);
$stmt->bindColumn('url',$url);
$stmt->execute();
echo "<table>";
echo"<tr>";
echo"<th>code</th>";
echo"<th>Nom</th>";
echo"<th>categorie</th>";
echo"<th>prixU</th>";
echo"<th>QuantiteStock</th>";
echo"<th>detailS</th>";
echo"<th>modifier</th>";
echo"<th>supprimer<th>";
echo"</tr>";
while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
{
  $c=$row['code'];
  $n=$row['nom'];
  $ca=$row['categorie'];
  $d=$row['description'];
  $q=$row['QuantiteStock'];
  $p=$row['prixU'];

  $reqim="SELECT url,id from image where codeproduit=$c";
  $resIn=$connect->query($reqim);
  if($resIn){
    $l=$resIn->fetch();
    $im=$l[0];
    $ID=$l['id'];
  }
  
  echo "<tr>";
echo "<td>";
 echo $c;
 echo"<td>";
   echo $n;
   echo"</td>";
   echo"<td>";
   echo$ca;
   echo"</td>";
   echo"<td>";
   echo$q;
   echo"</td>";
   echo"<td>";
   echo$p;
   echo"</td>";

 echo "</td>";
 echo "<td>";
//  echo "<form method='POST'  action='detail.php'>";
//  echo"<input type='hidden' name='detail' value='$c'/>";
//  echo "<input type='submit' name='voir' value='detail' />";
 echo"<a href='detail.php?code=$c'><img src='$im'/> </p>";
 echo "</form>";
 echo "</td>";
 echo "<td>";
 echo"<form method='post' action='modification.php'>";
 echo"<input type='hidden' name='modifie' value='$c'/>";
 echo"<input type='hidden' name='modifim' value='$ID'/>";
 echo "<input type='submit'id='btn' name='modifier' value='modifier'/>";
  echo"</form>";
  echo"</td>";
  echo"<td>";
  echo"<form method='post' action='produit.php'>";
  echo "<input type='hidden' name='idSupr' value='$c' />";
 echo "<input type='submit' name='supprimer' id='btn1' value='supprimer'/>";
 echo "</form>";
 echo "</td>";
  echo "</tr>";
 

}
echo "</table>";

if(isset($_POST['supprimer'])){
  $b=$_POST['idSupr'];
 $sql3="DELETE FROM  image  WHERE codeproduit=:cd";
  $stmt=$connect->prepare($sql3);
  $stmt->bindParam(':cd',$b,PDO::PARAM_INT);
  $stmt->execute();

  $req4="DELETE FROM  produit  WHERE code=:cod";
  $stmt=$connect->prepare($req4);
  $stmt->bindParam(':cod',$b,PDO::PARAM_INT);
  $stmt->execute();
  echo"suppression reussi";

 
   } 
  


  
              }

                   


 $connect=new PDO("mysql:host=localhost;port=3306;dbname=commercial","root","");

 if($connect)
 {

}









?>
</section>


<div id="hr">
<form method="post" id="formprod" action="<?php echo $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data">
<input type="file" multiple="multiple" name="photo[]" accept="image/*"/>
   <fieldset>
      <h2>table produit</h2>
    
    <label class="lb">code</label>
    <input type="text" name="code" /></p>
    <p><label class="lb">Nom</label>
    <input type="text" name="nom" id='nom'/></p>
    <p><label class="lb">categorie</label>
    <input type="text" name="categorie" minlenght="1" id='cat'/></p>
    <p><label class="lb">description</label>
    <textarea  name="descript" id='quant'></textarea></p>
    <p><label class="lb">QuantiteStock </label>
    <input type="number" name="quantitestock" id='quan' min="1"/></p>
    <p><label class="lb">prixU</label>
    <input type="decimal" name="prixU" id='prix' min="150"/></p>
    </fieldset>
     <input type="submit" value="envoyer" id="submit" />
     <input type="reset" value="annuler" id="submit" />
    </form>

</div>
<script>
  var nom=document.querySelector('#nom');
      nom.value='ordinateur';
      var des=document.querySelector('#quant');
      des.value='ordinateur portable derniere generation ram4GO DISK 500GO';
      var prix=document.querySelector('#prix');
      prix.value='150000';
      var quantite=document.querySelector('#quan');
      quantite.value='150';

      var c=document.querySelector('#cat');
      c.selectedIndex=2;


      var formu=document.getElementById



</script>
</body>
</html>