<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<section>
<?php
public class TestEq2Degre {

    $Equation1=new Eq2Degre(1,2,3);
    $Equation1->AfficheDiscriminant();
    echo"<br/>";
    $Equation1->resoudre();
    echo"<br/>";
    $Equation1=new Eq2Degre(2,4,6);
    $Equation1->AfficheDiscriminant();
    echo"<br/>";
    $Equation1->resoudre();
    echo"<br/>";
    $Equation1=new Eq2Degre(3,1,4);
    $Equation1->AfficheDiscriminant();
    echo"<br/>";
    $Equation1->resoudre();


}



?>




</section>
    
</body>
</html>