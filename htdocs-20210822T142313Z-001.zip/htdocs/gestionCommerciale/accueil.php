<?php
session_start();

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styleaccueil.css?t=<?php echo time();?>">
    <title>Document</title>
</head>
<body>
<div id="contenu">
<header>	
			<p> Bienvenu dans mon site</p>
				
		   </header>
		     je sais que tu es:<?php echo $_SESSION['login']; ?>
<nav>
		       <ul>
			       <li><a href="produit.php">Produit</a></li>
				   <li><a href="clients.php">Clients</a></li>
				   <li><a href="commande.php">Commandes</a></li>
				</ul>
			</nav>
</div>
</body>
</html>