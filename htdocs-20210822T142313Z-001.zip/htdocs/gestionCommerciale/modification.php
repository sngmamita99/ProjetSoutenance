<?php
session_start();
$_SESSION['prenom']='serigne';
$_SESSION['nom']='seck';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylemodification.css?t=<?php echo time();?>">
    <title>Document</title>
</head>
<body>


    
    <?php
    
 $connect=new PDO("mysql:host=localhost;port=3306;dbname=commercial","baye","seck");
   if($connect){

      
  echo"connection etablie";
  if(isset($_POST['subm'])){
      $code=$_POST['cod'];
       echo $_FILES['photo'];
   
    $extensions_ok = array( 'jpg' , 'jpeg' , 'gif' , 'png' );

    $extension_fichier = strtolower( substr(strrchr($_FILES['photo']['name'], '.'),1));
    if ( in_array($extension_fichier, $extensions_ok) )
         {
            echo "<p>Extension correcte du fichier</p>"; 
         }
 
       $dhc=date("dmy_his",time());
       $fic="mesphotos/".$dhc."_".$_FILES['photo']['name'];
       $result=move_uploaded_file($_FILES['photo']['tmp_name'],$fic);
       if($result){
       echo "<p>transfert du fichier reussi</p>";
       }

       $url="mesphotos/".$dhc."_".$_FILES['photo']['name'];
       $ident=$code;

       $req7="SELECT id from image where id=$code ";
       $stm=$connect->exec($req7);
       if($stm){
           $li=$stm->fetch();
           $ID=$li[0];
           echo $ID;
       }


       $req6="UPDATE image set url='$url' where id=$ID";
       $st=$connect->query($req6);
       if($st){
           echo "modification de l'image reussi";
       }
        
       echo"vous etes l'utilisateur:<br/>";
                 echo $_SESSION['prenom'];
                 echo"<br/>";
                 echo $_SESSION['nom'];   
        
}

  echo"<br/>";
  if(isset($_POST['sub'])){
      $cod=$_POST['cod'];
    $n=$_POST['nm'];
    $ca=$_POST['cate'];
    $de=$_POST['des'];
    $q=$_POST['quanT'];
    $p=$_POST['prix'];
    echo $cod,$n,$ca,$de,$q,$p;

   $req="UPDATE produit set nom='$n',categorie='$ca',description='$de',QuantiteStock=$q,prixU=$p where code=$cod";
   $stmt=$connect->query($req);
   //$stmt->execute(array($n,$ca,$de,$q,$p));
   if($stmt)
   {
   echo"modication  reussi";
   }


  }
  
  if(isset($_POST['modifier'])){
  $a=$_POST['modifie'];
  $prod=$_POST['modifim'];
   echo $prod;
   
    $req=$connect->prepare("SELECT* from produit join image on code=codeproduit where code=$a");
     $req->execute(array($a));
     while($row=$req->fetch()){
         echo $row['code'];
         echo $row['nom'];
         echo $row['categorie'];
         echo $row['description'];
         echo $row['QuantiteStock'];
         echo $row['prixU'];
         echo $row['id'];


         $co=$row['code'];
         $c=$row['nom'];
         $cat=$row['categorie'];
         $desc=$row['description'];
         $quant=$row['QuantiteStock'];
         $pr=$row['prixU']; 
         $id=$row['id'];
         
     }

        
    
     $req4="SELECT url from image where id=$id";
     $stmt=$connect->prepare($req4);
     $stmt->execute(array($id));
     if($stmt){
         echo "selection reussi";
         $l=$stmt->fetch();
         $im=$l[0];
     }

    
     
    }
 
    
     
}



?>
<div id="hr">
    <form method="POST" action="modification.php">
    <input type="hidden" name="cod"  value="<?php echo $co ?>" /></p>
    <input type="file" multiple="multiple" name="photo" accept="image/*" value="$im"/>
    <input type="submit" id="submit" value="modifier" name='subm' />
</form>
<form method="post" action="modification.php" >

   <fieldset>
      <h2>modification des produits</h2>
    <input type="hidden" name="cod"  value="<?php echo $co ?>" /></p>
      
    <p><label class="lb">Nom</label>
    <input type="text" name="nm" value="<?php echo $c ?>"/> </p>
    <p><label class="lb">categorie</label>
    <input type="text" name="cate" minlenght="1" value="<?php echo $cat ?>"/></p>
    <p><label class="lb">description</label>
    <input  name="des" value="<?php echo $desc ?>" /></p>
    <p><label class="lb">QuantiteStock </label>
    <input type="number" name="quanT" min="1" value="<?php echo $quant ?>"/></p>
    <p><label class="lb">prixU</label>
    <input type="decimal" name="prix" value="<?php echo $pr ?>" /></p>
    </fieldset>
     <input type="submit" id="submit" value="modifier" name='sub' />
     <input type="reset" id="submit" value="annuler" />
    </form>
</div>
</body>
</html>