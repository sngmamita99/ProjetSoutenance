<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>


<?php 
public class Electeur extends Personnee{

    private $bureau_de_vote;
    private $vote=false;

public function __construct($nom,$prenom,$bureau_de_vote,$vote){
    parent::__construct($nom,$prenom);
    $this->bureau_de_vote=$bureau_de_vote;
    $this->vote=$vote;
}
  public function avoter():boolean{
      if($vote)
      return true;
      else
      return false;
      
  }

}





?>
    
</body>
</html>