
<?php
session_start();
$_SESSION['nome']=$user;
if(isset($_POST['nome'])&& isset($_POST['mdp'])){

        $_SESSION['login']=$_POST['nome'];
        $use=$_SESSION['login'];

setcookie('login',$_POST['nome'],time()+365*24*3600);

}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php 

echo $_COOKIE['login'];


$connect=new PDO("mysql:host=localhost;port=3306;dbname=commercial","baye","seck");

if($connect){
    $sql="select* from users";
    $stmt=$connect->prepare($sql);
if(isset($_POST['nome']) && isset($_POST['mdp']))
{
    $login=$_POST['nome'];
    $motdepass=$_POST['mdp'];
    $use=$_SESSION['nome'];
    $use=isset($_SESSION['nome'])?$_SESSION['nome']:'';
  

    $stmt->bindColumn(':user', $login);
    $stmt->bindColumn(':password', $motdepass);
     $stmt->execute();
    while($row=$stmt->fetch()){
        if(($row['user']==$login) && ($row['password']==$motdepass)){
            
            $_SESSION['nome']=$log;

            echo $use;

            header("Location:accueil.php");
        }
    
    else{
        header("Location:connexion.php");
    
        }
    }
   
}
}

 ?>
</body>
</html> 