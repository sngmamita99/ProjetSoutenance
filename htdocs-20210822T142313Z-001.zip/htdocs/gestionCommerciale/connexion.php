<?php
session_start();
if(isset($_POST['nome'])){
    $us=$_POST['nome'];

    setcookie('login',$us,time()+365*24*3600);

    echo $_COOKIE['login'];
    
    }
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styleconnexion.css?t=<?php echo time();?>">
    <title>Document</title>
</head>
<body>
    <?php
  





?>
    <div id="contenu">

                           
    
    <form method="POST" action="Authentification.php">
    <div id="conn">
    <h3>connexion</h3>
    <p><label class="lb" for="lg"> login </label>
    <input type="text"  name="nome" id="lg" value="<?php echo $log ?>" /></p>
    <p><label class="lb"  for="pwd">password </label>
    <input type="password"  name="mdp" value="$pass" id="pwd"/></p>
    <input type="submit"  name="code" id="eny"/>
    <input type="reset"  name="code" value="annuler" id="anl"/>
</div>
</form>
</div>
</body>
</html>