
<?php
session_start();
$_SESSION['prenom']='serigne';
$_SESSION['nom']='seck';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styledetail.css?t=<?php echo time();?>">
    <title>Document</title>
</head>
<body>
<section>
    <?php

echo"vous etes l'utilisateur:<br/>";
echo $_SESSION['prenom'];
echo"<br/>";
echo $_SESSION['nom'];
     $connect=new PDO("mysql:host=localhost;port=3306;dbname=commercial","baye","seck");

     if($connect)
     {
        echo "la connection est etablie";
        
        echo"<br/>";
           
          
                if(isset($_GET['code'])){
                    $voir=$_GET['code'];
                    $sql1="SELECT* from produit join image on code=codeproduit Where code=:coder";
                    $stmt=$connect->prepare($sql1);
                    $stmt->bindParam(':coder',$voir);
                    $stmt->execute();
                       while($row=$stmt->fetch()){
                           if($row['code']==$voir){
                               $e=$row['description'];
                               $t=$row['categorie'];
                                 $a=$row['url'];
                              echo "<img src='$a'/> \t\t\t";
                             }
                            }
                            echo"<br/>";
                            echo"<p>$e</p>";
                            echo"<br/>";
                            echo"<p>$t</p>";
                            
                        }
                        else
                echo "echec";

}


?>
</section>
</body>
</html>