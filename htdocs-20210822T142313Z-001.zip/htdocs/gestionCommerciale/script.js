var d1_document=document.getElementById("d1");
var d2_document=document.getElementById("d2");
d1_document.setAttribute("className","bl");
d2_document=className="yel";