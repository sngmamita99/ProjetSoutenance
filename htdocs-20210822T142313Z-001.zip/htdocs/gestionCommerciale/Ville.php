<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

    public class ville{
        private $nom;
        private $departement;
        private $region;
        private $nb_habitant;

        public function __construct($nom,$departement,$region,$nb_habitant){
            $this->nom=$nom;
            $this->departement=$departement;
            $this->region=$region;
            $this->nb_habitant=$nb_habitant;

        }
        public function getNom(){
            return $this->nom;
        }
        public function getDepartement(){
            return $this->departement;
        }
        public function getRegion(){
            return $this->region;
        }
        public function getNb_habitant(){
            return $this->nb_habitant;
        }
       public function setNom($nom){
           $this->nom=$nom;
       }
       public function setDepatement($departement){
        $this->departement=$departement;
    }
    public function setRegion($region){
        $this->region=$region;
    }
    public function setNb_habitant($nb_habitant){
        $this->nb_habitant=$nb_habitant;
    }
    public function afficheInfoVille():void{
        echo $this->nom;
        echo "<br/>";
        echo $this->departement;
        echo "<br/>";
        echo $this->region;
        echo $this->nb_habitant;

    }