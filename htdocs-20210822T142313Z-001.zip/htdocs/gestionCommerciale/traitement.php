<?php
session_start();
$_SESSION['prenom']='serigne';
$_SESSION['nom']='seck';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styletraitement.css?t=<?php echo time();?>">
    <title>Document</title>
</head>
<body>
    <section>
     <h2>bienvenu a la page de recherche de produits</h2>


    <?php

echo"vous etes l'utilisateur:<br/>";
echo $_SESSION['prenom'];
echo"<br/>";
echo $_SESSION['nom'];
    $connect=new PDO("mysql:host=localhost;port=3306;dbname=commercial","baye","seck");
         
    if($connect){
        echo "la connexion est etablie<br/>";
        $sql="select* from produit join image on code=codeproduit";
        $stmt=$connect->prepare($sql);
        if(isset($_POST['rechprod'])){
            $categorie=$_POST['rechprod'];
            $nom=$_POST['rechprod'];
            $stmt->execute(array('categorie'=>$categorie,
            'nom'=>$nom));
            echo "<table>";
echo"<tr>";
echo"<th>code</th>";
echo"<th>nom</th>";
echo"<th>description</th>";
echo"<th>categorie</th>";
echo"<th>QuantiteStock</th>";
echo"<th>PrixU</th>";
echo"<th>photo</th>";
echo"</tr>";
            while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
              
                if(($_POST['rechprod']==$row['categorie']) || ($_POST['rechprod']==$row['nom'])){
                    echo"<tr>";
                    echo"<td>";
                    echo $row['code'];
                    echo"</td>";
                    echo"<td>";
                    echo $row['categorie'];
                    echo"</td>";
                    echo"<td>";
                    echo$row['description'];
                    echo"</td>";
                    echo"<td>";
                    echo$row['nom'];
                    echo"</td>";
                    echo"<td>";
                    echo $row['prixU'];
                    echo"</td>";
                    echo"<td>";
                    echo $row['QuantiteStock'] ;
                    echo"</td>";
                    echo"<td>";
                    $a=$row['url'];
                    echo "<p><img src='$a'/>";
                    echo"</td>";
                    echo"</tr>";
                
            }
           
        }
        echo"<table>";
       
    }
  
}


?>
</section>
</body>
</html>