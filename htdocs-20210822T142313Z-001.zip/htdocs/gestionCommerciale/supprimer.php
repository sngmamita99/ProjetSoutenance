<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
 $connect=new PDO("mysql:host=localhost;port=3306;dbname=commercial","baye","seck");

 if($connect)
 {
if(isset($_POST['supprimer'])){
                  $b=$_POST['idSupr'];
                 $sql3="DELETE FROM produit join image on code=codeproduit WHERE codeproduit=:cd";
                  $stmt=$connect->prepare($sql3);
                  $stmt->bindParam(':cd',$b,PDO::PARAM_INT);
                  $stmt->execute();
                  echo"suppression reussi";
                   } 
                }
?>
</body>
</html>