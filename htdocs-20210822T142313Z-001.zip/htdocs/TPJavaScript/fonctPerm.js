//Si utilisateur donne son accord on permute les 2 lises en 
var conf=confirm("Voulais vous permuter les mises en formes des conteneurs");
if(conf){	
    elt1.className="yel";
	elt2.setAttribute("class", "bl");
}