
function checkAge(a){
	//return a<=35 && a>=17;on pourait ecrire seulement cette ligne
	if(a>35 || a<17)
		return false;
	return true;
}
