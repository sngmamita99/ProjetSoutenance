var numqt=document.getElementById("quit");
var nCE=document.getElementById("numCE");

nCE.addEventListener("change",function(){
	var v=nCE.value;
	var tdg=v.substring(0,4);
	// alert(typeof(tdg));
	if(tdg < "2017" || tdg > "2021"){
		alert("incorrect! le numéro doit débuter par un nombre compris entre 2017 et 20121");
		nCE.value="";
	}
},false);

numqt.addEventListener("keyup",function(){
	var chiffres = new RegExp("[0-9]");
	var test;
	var p=0;
	for(var i=0; i<numqt.value.length;i++){
		test = chiffres.test(numqt.value.charAt(i));
		if(numqt.value.charAt(i) == "."){
			p++;
		}
		if(p > 1){
			test=false;
			p=1;
		}
		if(test==false){
			numqt.value = numqt.value.substr(0,i)+numqt.value.substr(i+1,numqt.value.length-i+1); i--;
			alert("Entrer uniquement des chiffres");
		}
	}
 }, false);

