function ajouter(nAge){
	objetud.age=nAge;
}
var AJC=prompt("Ajouter Champ age");
ajouter(AJC);
document.write("<h3>Affichage apres ajout d'un nouveau champ</h3>");
afficher();
