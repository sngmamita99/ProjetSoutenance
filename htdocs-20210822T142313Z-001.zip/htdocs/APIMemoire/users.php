<?php
  // Se connecter à la base de données
  $y=include("db_connect.php");
  $request_method = $_SERVER["REQUEST_METHOD"];

?>

<?php
  switch($request_method)
  {
    case 'GET':
      if(!empty($_GET["id"]))
      {
        // Récupérer un seul users
        $id = intval($_GET["id"]);
        getProducts($id);
      }
      else
      {
        // Récupérer tous les users
        getProducts();
      }
      break;
	case 'POST':
      // Ajouter un users
      AddProduct();
      break;
	case 'PUT':
       // Modifier un users
       $id = intval($_GET["id"]);
       updateProduct($id);
       break;
	case 'DELETE':
    // Supprimer un users
    $id = intval($_GET["id"]);
    deleteProduct($id);
    break;
    default:
      // Requête invalide
      header("HTTP/1.0 405 Method Not Allowed");
      break;
  }
?>

<?php
  function getProducts()
  {
    global $conn;
    $query = "SELECT * FROM users";
    $response = array();
    $result = mysqli_query($conn, $query);
    while($row = mysqli_fetch_array($result))
    {
      $response[] = $row;
    }
    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT);
  }
?>

<?php
      function getProduct($id=0)
  {
    global $conn;
    $query = "SELECT * FROM users";
    if($id != 0)
    {
      $query .= " WHERE id=".$id." LIMIT 1";
    }
    $response = array();
    $result = mysqli_query($conn, $query);
    while($row = mysqli_fetch_array($result))
    {
      $response[] = $row;
    }
    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT);
  }
?>

<?php
  function AddProduct()
  {
    global $conn;
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $adresse = $_POST["adresse"];
    $email = $_POST["email"];
    $numTel = $_POST["numTel"];
    $etat = $_POST["etat"];
    $created = date('Y-m-d H:i:s');
    $modified = date('Y-m-d H:i:s');

    echo $query="INSERT INTO users(nom, prenom, adresse, email, numTel, etat,created,modified) VALUES('".$nom."', '".$prenom."', '".$adresse."', '".$email."','".$numTel."','".$etat."', '".$created."', '".$modified."')";

    if(mysqli_query($conn, $query))
    {
      $response=array(
        'status' => 1,
        'status_message' =>'users ajoute avec succes.'
      );
    }
    else
    {
      $response=array(
        'status' => 0,
        'status_message' =>'ERREUR!.'. mysqli_error($conn)
      );
    }
    header('Content-Type: application/json');
    echo json_encode($response);
  }
?>

<?php
  function updateProduct($id)
  {
    global $conn;
    $_PUT = array(); //tableau qui va contenir les données reçues
    parse_str(file_get_contents('php://input'), $_PUT);
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $adresse = $_POST["adresse"];
    $email = $_POST["email"];
    $numTel = $_POST["numTel"];
    $etat = $_POST["etat"];
    $modified = date('Y-m-d H:i:s');

    //construire la requête SQL
    $query="UPDATE users SET nom='".$nom."', prenom='".$prenom."', adresse='".$adresse."', email='".$email."',numTel='".$numTel."',etat='".$etat."', modified='".$modified."' WHERE id=".$id;
    
    if(mysqli_query($conn, $query))
    {
      $response=array(
        'status' => 1,
        'status_message' =>'users mis a jour avec succes.'
      );
    }
    else
    {
      $response=array(
        'status' => 0,
        'status_message' =>'Echec de la mise a jour de users. '. mysqli_error($conn)
      );
      
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
  }
?>

<?php
  function deleteProduct($id)
  {
    global $conn;
    $query = "DELETE FROM users WHERE id=".$id;
    if(mysqli_query($conn, $query))
    {
      $response=array(
        'status' => 1,
        'status_message' =>'users supprime avec succes.'
      );
    }
    else
    {
      $response=array(
        'status' => 0,
        'status_message' =>'La suppression du users a echoue. '. mysqli_error($conn)
      );
    }
    header('Content-Type: application/json');
    echo json_encode($response);
  }
?>