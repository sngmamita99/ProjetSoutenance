<?php
$url = "http://127.0.0.1/APIMemoire/users/1"; // modifier le produit 1
$data = array('nom' => 'Ordinateur portable', 'prenom' => '9658', 'adresse' => '2', 'email' => '9', 'numTel' => '9', 'etat' => '9');

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($data));

$response = curl_exec($ch);

var_dump($response);

if (!$response) 
{
    return false;
}
?>