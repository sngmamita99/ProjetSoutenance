<?php
  $server = "localhost";
  $username = "root";
  $password = "";
  $db = "projetsoutenance";
  $conn = mysqli_connect($server, $username, $password, $db);
?>