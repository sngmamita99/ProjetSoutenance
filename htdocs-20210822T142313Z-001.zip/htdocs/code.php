<!--nom et prenom>
<?php
echo 'yes';
    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	if($connect){
	    if(isset($_POST['nom']) AND isset($_POST['prenom']) AND isset($_POST['lg']) AND isset($_POST['mdp']) AND isset($_POST['numtel']) AND isset($_POST['email']) AND isset($_POST['maliste']) AND isset($_POST['dtnss'])){
	     	$nom=$_POST['nom'];
			$pnom=$_POST['prenom'];
			$lg=$_POST['lg'];
			$mdp=$_POST['mdp'];
			$numtel=$_POST['numtel'];
			$email=$_POST['email'];
			$maliste=$_POST['maliste'];
			$dtnss=$_POST['dtnss'];
		    $req="INSERT INTO membre (nom,penom,login,password,ulhphoto,statut,numeroTel,email,genre,datenaiss)VALUES 
			('$nom','$pnom','$lg','$mdp','photo','deconnecté','$numtel','$email','$maliste','$dtnss')";
			$res=$connect->exec($req);
			// $idmbre=$connect->lastInsertId();			
			// header("Location:accueil.php");
		}
		echo 'insertion failed';
	}
	else
		echo 'connexion à la BD non établie';
		
// <!--login et mot de passe>

		    // $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
			// if($connect){
				
				// $idmbre=$connect->lastInsertId();
				// echo $idmbre;
				
			    // if(isset($_POST['lg']) AND isset($_POST['mdp'])){
					// $lg=$_POST['lg'];
					// $mdp=$_POST['mdp'];
					// $req2="UPDATE membre SET login='$lg',password='$mdp' WHERE idmbre=$idmbre";
					// $res2=$connect->query($req2);
					// header("Location:inscription3NTE.php");
				// }
			
			// else
				// echo 'connexion à la BD non établie';
		
		// ,'login','password','ulhphoto','statut','numeroTel','email','genre','datenaiss'
		// ,[value-3],[value-4],[value-5],[value-6],[value-7],[value-8],[value-9],[value-10],[value-11])
		
// <!--numéro telephone et email>		
		
		

		    // $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
			// if($connect){
				// $idmbre=$connect->lastInsertId();
			    // if(isset($_POST['numtel']) AND isset($_POST['email'])){
					// $numtel=$_POST['numtel'];
					// $email=$_POST['email'];
					// $req3="UPDATE membre SET numeroTel='$numtel',email='$email' WHERE idmbre=$idmbre";
					// $res3=$connect->query($req3);
					// header("Location:inscription4GDN.php");
				// }	    
			
			// else
				// echo 'connexion à la BD non établie';

		
// <!--genre et date de naissance>		

		    // $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
			// if($connect){
				// $idmbre=$connect->lastInsertId();
			    // if(isset($_POST['maliste']) AND isset($_POST['dtnss'])){
					// $maliste=$_POST['maliste'];
					// $dtnss=$_POST['dtnss'];
					// $req4="UPDATE membre SET genre='$maliste',datenaiss='$dtnss' WHERE idmbre=$idmbre";
					// $res4=$connect->query($req4);
					// header("Location:inscription5PP.php");
				// }
			// }
			// else
				// echo 'connexion à la BD non établie';
		
// <!--photo de profil>


		    // $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
			// if($connect){
			    // if(isset($_FILES['phtpfl'])){
					// $fname=$_FILES['phtpfl']['name']; 
                    // $tmpname=$_FILES['photo']['tmp_name'];				
                    // $extensions_ok = array('jpg','jpeg','gif','png'); 
                    // $extension_fichier = strtolower( substr(strrchr($fname ,'.'),1));
                    // if ( in_array($extension_fichier, $extensions_ok) ){
                         // echo "<p>Extension correcte du fichier</p>"; 
                    // }    
                    // $dhc=date("dmy_his",time());
                    // $fic="mesphotos/".$dhc."_".$fname;
                    // $result=move_uploaded_file($tmpname,$fic);
                    // if($result){
                        // echo "<p>transfert du fichier reussi</p>";
                    // }
                    // $url="mesphotos/".$dhc."_".$fname;
                    // $url=$fic;
                    // $codeproduit=$code;                          
                    // $req5="UPDATE membre SET urlphoto=':urlphoto' WHERE idmbre=1";					
                    // $req1="INSERT INTO image VALUES(:id,:url,:codeproduit)";
                    // $stmt=$connect->prepare($req5);
                    // $stmt->bindParam(':urlphoto',$url);
                    // $stmt->execute() ;  
                    // header("Location:accueil.php");					
                              
                               
                       // }
			// }
                     
					
				
			// }
			// else
				// echo 'connexion à la BD non établie';
		?>		
		
		
		while($lign=$res2->fetch()){
		                $n=$lign['nom'];
		                $pn=$lign['penom'];
			            $pp=$lign['urlpp'];
						$d=$lign['demandeur'];
						$c=$lign['cible'];
						if($lign['genre']=='Homme'){
                            echo '<p><img src="$pp"/>';          
                            echo $pn.' '.$n; 
							
							if($id==$d)
							    echo '<a href="traiterSMS.php?code='.$c.'"><button id="btn">Demarrer une discution avec lui</button></a></p> ';
							else
								echo '<a href="traiterSMS.php?code='.$d.'"><button id="btn">Demarrer une discution avec lui</button></a></p> ';
                        }
                        else{
							echo '<p><img src='."$pp".'></img>';          
                            echo $pn.' '.$n;
							if($id==$d)
                                echo '<a href="traiterSMS.php?code='.$c.'&nom='.$n.'&prenom='.$pn.'"><button id="btn">Demarrer une discution avec elle</button></a></p>';
							else
							    echo '<a href="traiterSMS.php?code='.$d.'"><button id="btn">Demarrer une discution avec elle</button></a></p>';
						}
                    }  
                    				
	                }	
					
					
					
					
					
					
					
while($lign=$res2->fetch()){
		                $n=$lign['nom'];
		                $pn=$lign['penom'];
			            $pp=$lign['urlpp'];
						$d=$lign['demandeur'];
						$c=$lign['cible'];
						$dt=date("y-m-d");
						$h=time();
						if($lign['genre']=='Homme'){
                            echo '<p><img src="$pp"/>';          
                            echo $pn.' '.$n; 
							echo '<button id="btn">Demarrer une discution avec lui</button></p> ';
							if(!empty($_POST['sms'])){
							    $sms=$_POST['sms'];								
								if($id==$d){
								    $req="INSERT INTO message (emetteur,destinataire,contenue,date,heure)VALUES('$id','$c','$sms','$dt','$h')";
								    $res=$connect->query($req);
									break;
								}
								else{
									$req="INSERT INTO message (emetteur,destinataire,contenue,date,heure)VALUES('$id','$d','$sms','$dt','$h')";
							         $res=$connect->query($req);
									 break;
								}
								break;
							}
						
                        }
                        else{
							echo '<p><img src='."$pp".'></img>';          
                            echo $pn.' '.$n;							
                            echo '<button id="btn">Demarrer une discution avec elle</button></p>';
							if(!empty($_POST['sms'])){
							    $sms=$_POST['sms'];								
								if($id==$d){
								    $req="INSERT INTO message (emetteur,destinataire,contenue,date,heure)VALUES('$id','$c','$sms','$dt','$h')";
								    $res=$connect->query($req);
								}
								else{
									$req="INSERT INTO message (emetteur,destinataire,contenue,date,heure)VALUES('$id','$d','$sms','$dt','$h')";
							         $res=$connect->query($req);
								}
							}
							    // echo '<a href="traiterSMS.php?code='.$d.'"><button id="btn">Demarrer une discution avec elle</button></a></p>';
						}
                    }  