<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="administrateur.css?t=<?php echo time();?>">
    <title>Document</title>
    </head>
    <body>
        <section>
            <a href="officier.php"><button>OFFICIER D'ETAT CIVIL</button></a>
            <a href="agent.php"><button>AGENT</button></a>
            <a href="citoyen.php"><button>CITOYEN</button></a>
            <a href="livreur.php"><button>LIVREUR</button></a>
        </section>
    </body>
</html>