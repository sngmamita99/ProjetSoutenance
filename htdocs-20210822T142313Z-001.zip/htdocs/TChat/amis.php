<?php
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
	    <meta charset="utf-8" />
		<title>MamiTChat</title>
	    <link rel="stylesheet" href="amis.css?t=<?php echo time();?>"/> 
	</head>
	<div id="body">
	<nav>
	 
	    <h1 id='h1'>MamiTChat</h1>
		<p id="p1">
		    <?php
		    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
		    $id=$_SESSION['idmbre'];
		    $req1="SELECT nom,penom,genre FROM membre WHERE idmbre='$id'";
		    $res1=$connect->query($req1);
			if($res1){
			    while($ligne=$res1->fetch())
					if($ligne['genre']=="Homme")
			            echo $ligne['penom'].' '.$ligne['nom'].'<br><span>connecté</span>';
					else
						echo $ligne['penom'].' '.$ligne['nom'].'<br><span>connectée</span>';
		    }          
		 ?>
		</p>   		
      <p id="p2">  		
	    <ul>
		    <li>
			    <a href="accueil.php">Accueil</a>
			</li>
			
			<li>
			    <a href="membre.php">Voir les MamiTChaters</a>
			</li>
			<li>
			    <a href="amis.php">Mes Ami(e)s MamiTChaters</a>
			</li>
		</ul>
		</p> 
	</nav>
	
	<body>   
		    <div id="div1">
			   <h2>Mes Amies</h2>
			    <?php 
	                $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	                if($connect){
		            $id=$_SESSION['idmbre'];		            
		            $req2="select DISTINCT demandeur,cible,nom,penom,genre,urlpp from amitié a, membre m WHERE (a.demandeur='$id' AND a.etat='1' AND m.idmbre<>'$id' AND a.cible=m.idmbre) OR (a.cible='$id' AND a.etat='1' AND m.idmbre<>'$id' AND a.demandeur=m.idmbre)";
		            $res2=$connect->query($req2);
		            while($lign=$res2->fetch()){
		                $n=$lign['nom'];
		                $pn=$lign['penom'];
			            $pp=$lign['urlpp'];
						$d=$lign['demandeur'];
						$c=$lign['cible'];
						if($lign['genre']=='Homme'){
                            echo '<p id="pinp">';
							    echo '<img src='."$pp".'></img>';          
                                echo '<span id="pph">'.$pn.' '.$n.'</spanp>'; 
							
							if($id==$d)
							    echo '<a href="Discution.php?code='.$c.'&nom='.$n.'&prenom='.$pn.'"><button id="btn">Demarrer une discution avec lui</button></a></p> ';
							else
								echo '<a href="Discution.php?code='.$d.'&nom='.$n.'&prenom='.$pn.'"><button id="btn">Demarrer une discution avec lui</button></a></p> ';
						}
                        else{
							echo '<p id="pinp">';
							    echo '<img src='."$pp".'></img>';          
                                echo '<span id="pph">'.$pn.' '.$n.'</span>'; 
							    if($id==$d)
                                    echo '<a href="Discution.php?code='.$c.'&nom='.$n.'&prenom='.$pn.'"><button id="btn">Demarrer une discution avec elle</button></a></p>';
							    else
							        echo '<a href="Discution.php?code='.$d.'&nom='.$n.'&prenom='.$pn.'"><button id="btn">Demarrer une discution avec elle</button></a></p>';
						}
                      
                    				
	                }
                    				
	                }	
                ?>		
			</div>							   
	</body>
	</div>
</html>
		

