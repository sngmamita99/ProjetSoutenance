setInterval(function(){
var p=document.getElementById('pp');
var objb = new XMLHttpRequest();
var url="afficherSMS.php";
objb.open('GET',url);
objb.send(null);

objb.onreadystatechange=function(){
    if(objb.readyState==4){
        if(objb.status==200){
            p.innerHTML=objb.responseText;									
        }
   }				
}
},50);
					