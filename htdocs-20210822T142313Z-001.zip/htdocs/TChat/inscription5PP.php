<?php
	session_start();
?>
<?php
    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	if($connect){
			
	    if(isset($_POST['maliste']) AND isset($_POST['dtnss'])){
			$maliste=$_POST['maliste'];
			$dtnss=$_POST['dtnss'];		
			$idmbre=$_SESSION['idmbre'];
		    $req2="UPDATE membre SET genre='$maliste',datenaiss='$dtnss' WHERE idmbre='$idmbre'";
			$res=$connect->query($req2);		
		 }
	}
	else
		echo 'connexion à la BD non établie';
	
	?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>tchat</title>
        <link rel="stylesheet" href="authentification.css?t=<?php echo time();?>"/> 
	</head>
    <body>
	    
	    <div id="div1">
		    <p id="par1">
	        <h1 id='h1'>MamiChat</h1>     
	        <h3 id='h3'><marquee>Choisir une Photo de Profil</marquee></h3>  
            </p>			
	        <form id="form" method="post" action="accueil.php" enctype='multipart/form-data'>
			    <p class="labp">
     		        <label class="labp">Photo de Profil</label>
                    <input  id="inpp" type="file" id='rech' name="photo"/>
			    </p>
				<p>
                   <input id="sub" type="submit" value="s'inscrire"/>
                </p>
            </form>
			<a href="inscription4GDN.php"><button  id="btn"value="suivant">RETOUR</button></a>
        </div>	
        
	</body>
	<script  ></script>
</html>
		

