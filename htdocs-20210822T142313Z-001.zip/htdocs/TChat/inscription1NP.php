<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>tchat</title>
        <link rel="stylesheet" href="authentification.css?t=<?php echo time();?>"/> 
	</head>
    <body>
	    <div id="div1">
		    <p id="par1">
	        <h1 id='h1'>MamiTChat</h1>     
	        <h3 id='h3'><marquee>Donner votre nom et prénom</marquee></h3>  
            </p>			
	        <form id="form" method="post" action="inscription2LM.php" enctype='multipart/form-data'>
                <p id="aut">
     		        <label class="lab">Nom</label><br>
                    <input  id="inp1" type="text" id='rech' name="nom" required="required"/>
			    </p>
				<p id="aut">
     		        <label class="lab">Prénom</label><br>
                    <input  id="inp1" type="text" id='rech' name="prenom" required="required"/>
			    </p>
				    
				<p>
                   <input id="sub" type="submit" value="suivant"/>
                </p>
            </form>
			<a href="authentification.php"><button id="btn" value="suivant">RETOUR</button></a>
        </div>		
	</body>
	<script  ></script>
</html>
		

