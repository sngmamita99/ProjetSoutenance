<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>tchat</title>
        <link rel="stylesheet" href="authentification.css"/> 
	</head>
    <body>
	    <div id="div1">
		    <p id="par1">
	        <h1 id='h1'>MamiChat</h1>     
	        <h3 id='h3'><marquee>Veuillez emplir les champs SVP</marquee></h3>  
            </p>			
	        <form id="form" method="post" action="" enctype='multipart/form-data'>
                <p id="aut">
     		        <label class="lab">Nom</label>
                    <input  id="inp1" type="text" id='rech' name="nom" required="required"/>
			    </p>
				<p id="aut">
     		        <label class="lab">Prénom</label>
                    <input  id="inp1" type="text" id='rech' name="prenom" required="required"/>
			    </p>
				    <p>
			        <label class="lab">Login(non d'utilisateur)</label>
                    <input id="inp2" type="text" name="lg" required="required"/>
                </p>
				<p id="aut">
     		        <label class="lab">password</label>
                    <input  id="inp1" type="text" id='rech' name="mdp" required="required"/>
			    </p>
				<p>
			        <label class="lab">Numéro de téléphone</label>
                    <input id="inp2" type="text" name="numtel" value=""/>
                </p>
				<p id="aut">
     		        <label class="lab">Adresse email</label>
                    <input  id="inp1" type="text" id='rech' name="email"/>
			    </p>
				<p>
				    <label class="lab">Votre Genre</label>
				    <select name="maliste" required="required">
                        <option value="Homme"></option>
                        <option value="Homme">Homme</option>
                        <option value="Femme">Femme</option>
                    </select>
                </p>
				<p id="aut">
     		        <label class="lab">Date de Naissance</label>
                    <input  id="inp1" type="date" id='rech' name="dtnss"/>
			    </p>
				<p id="aut">
     		        <label class="lab">Photo de Profil</label>
                    <input  id="inp1" type="file" id='rech' name="photo" accept="image/*" />
			    </p>
				
				<p>
                   <input id="sub" type="submit" value="suivant"/>
                </p>
            </form>
			<a href="authentification.php"><button value="suivant">RETOUR</button></a>
        </div>		
	</body>
	 <?php
    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	if($connect){
			
	    if(isset($_POST['nom']) AND isset($_POST['prenom']) AND isset($_POST['lg']) AND isset($_POST['mdp'])
			AND isset($_POST['numtel']) AND isset($_POST['email']) AND isset($_POST['maliste']) AND isset($_POST['dtnss'])){
	     	$nom=$_POST['nom'];
			$pnom=$_POST['prenom'];
			$lg=$_POST['lg'];
			$mdp=$_POST['mdp'];
			$numtel=$_POST['numtel'];
			$email=$_POST['email'];
			$maliste=$_POST['maliste'];
			$dtnss=$_POST['dtnss'];		
			
			if(isset($_FILES['photo'])){               
                $extensions_ok = array( 'jpg' , 'jpeg' , 'gif' , 'png' );
   
                $extension_fichier = strtolower( substr(strrchr($_FILES['photo']['name'], '.'),1));
                if ( in_array($extension_fichier, $extensions_ok) ){
                    echo "<p>Extension correcte du fichier</p>"; 
                }
                $dhc=date("dmy_his",time());
                $fic="mesphotos/".$dhc."_".$_FILES['photo']['name'];
                $result=move_uploaded_file($_FILES['photo']['tmp_name'],$fic);
                if($result){
                    echo "<p>transfert du fichier reussi</p>";
                }
                $url="mesphotos/".$dhc."_".$_FILES['photo']['name'];               
		        $req="INSERT INTO membre (nom,penom,login,password,numeroTel,email,genre,datenaiss,urlpp,statut)VALUES('$nom','$pnom','$lg','$mdp','$numtel','$email','$maliste','$dtnss','$url','0')";
			    $res=$connect->query($req);
			    $_SESSION['idmbre']=$connect->lastInsertId();
			}
			else
				echo 'insertion photo failed';
		 }
	}
	else
		echo 'connexion à la BD non établie';
?>
	<script  ></script>
</html>
		

