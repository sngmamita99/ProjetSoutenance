<?php 
    session_start();
    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	if($connect){
		$id=$_SESSION['idmbre'];
		$cd=$_SESSION['code'];
        $reqt="select*from message where (emetteur='$id' and destinataire='$cd') or (emetteur='$cd' and destinataire='$id')";
	    $rest=$connect->query($reqt);	
		$reqi1="select urlpp from membre where idmbre='$id'";
	    $resi1=$connect->query($reqi1);
        $lig=$resi1->fetch();	
        $reqi2="select urlpp from membre where idmbre='$cd'";
	    $resi2=$connect->query($reqi2);
        $lign=$resi2->fetch();				
	    while($lg=$rest->fetch()){
		    if($lg['emetteur']==$id and $lg['destinataire']==$cd)
		        echo '<p id="pp1"><img id="imgm" src="'.$lig['urlpp'].'"></img><span id="ctn">'.$lg['contenue'].'</span><br><span id="dthre">le '.$lg['date'].' à '.$lg['heure'].'</span></p>';
		    else
		        echo '<p id="pp2"><img id="imgm" src="'.$lign['urlpp'].'"></img><span id="ctn">'.$lg['contenue'].'</span><br><span id="dthrr">le '.$lg['date'].' à '.$lg['heure'].'</span></p>';
		}
	}
?>