<?php
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
	    <meta charset="utf-8" />
		<title>MamiTChat</title>
	    <link rel="stylesheet" href="traiterSMS.css?t=<?php echo time();?>"/> 
	</head>
	<nav>
	    <h1 id='h1'>MamiTChat</h1>
		<p id="p1">
		    <?php
		    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
		    $id=$_SESSION['idmbre'];
		    $req1="SELECT nom,penom,genre FROM membre WHERE idmbre='$id'";
		    $res1=$connect->query($req1);
			if($res1){
			    while($ligne=$res1->fetch())
					if($ligne['genre']=="Homme")
			            echo $ligne['penom'].' '.$ligne['nom'].'<br><span>connecté</span>';
					else
						echo $ligne['penom'].' '.$ligne['nom'].'<br><span>connectée</span>';
		    }          
		 ?>
		</p>   	
	    <ul>
		    <li>
			    <a href="accueil.php">Accueil</a>
			</li>
			
			<li>
			    <a href="membre.php">Voir les MamiTChaters</a>
			</li>
			<li>
			    <a href="amis.php">Mes Ami(e)s MamiTChaters</a>
			</li>
		</ul>
	</nav>
	<body>   
		<div id="DIV">
		    <div id="div1">
			    <?php
                    $cd=$_GET['code'];
                    $nm=$_GET['nom'];
                    $pn=$_GET['prenom'];
	                echo '<p id="dis">Discution avec '.$nm.' '.$pn.'</p>';
                ?>
			    <?php 
	                $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	                if($connect){
		                $id=$_SESSION['idmbre'];		                
		                $req2="select DISTINCT demandeur,cible,nom,penom,genre,urlpp,statut from amitié a, membre m WHERE (a.demandeur='$id' AND a.etat='1' AND m.idmbre='$cd' AND a.cible='$cd') OR (a.cible='$id' AND a.etat='1' AND m.idmbre='$cd' AND a.demandeur='$cd')";
		                $res2=$connect->query($req2);
		                while($lign=$res2->fetch()){
		                    $n=$lign['nom'];
		                    $pn=$lign['penom'];
			                $pp=$lign['urlpp'];
						    $d=$lign['demandeur'];
						    $c=$lign['cible'];
						    			
						    if($d==$cd || $c==$cd){
                                echo '<p id="pinp">';
								    echo '<img src='."$pp".'></img>';          
                                    echo '<span id="pph">'.$pn.' '.$n.'</span>'; 
									// if($lign['statut']=='1')
										// echo '<br><span id="connect">en ligne</span>';
									// else{
										// if($lign['genre']=="Homme")
										    // echo '<br><span id="connectd">deconnecté</span>';
										// else
											// echo '<br><span id="connectd">deconnectée</span>';
									// }
							    echo '</p>';
							    break;
		     			   }
					    }					
					}
					
                ?>	
                				
			    </div>
             <?php
				    $id=$_SESSION['idmbre'];
					$dt=date("y-m-d");
				    $h=date("H:i:s");		
				    if(!empty($_POST['sms'])){
					    $sms=$_POST['sms'];								
				        $req="INSERT INTO message (emetteur,destinataire,contenue,date,heure)VALUES('$id','$cd','$sms','$dt','$h')";
			            $res=$connect->query($req);	
                    }	
                    $_SESSION['code']=$cd;					
			?>				
	        <div id="div2">
			<p id="pp"></p>
			<script  src= "amis.js "></script>
	        <form id="form" method="post" action="">
                <p id="aut">
                    <textarea  id="inp1" name="sms" required="required" placeholder="saisissez votre message"></textarea>
				    <input id="sub" type="submit" value="envoyer"/>
			    </p>
            </form>
			</div>				   
	</body> 
</html>
		

