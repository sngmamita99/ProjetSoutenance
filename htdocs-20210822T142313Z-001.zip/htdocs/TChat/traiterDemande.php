<?php
	session_start();
	$connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
    $cd=$_GET['cdd'];
	$id=$_SESSION['idmbre'];
	$req="INSERT INTO amitié(demandeur,cible,etat) VALUES ('$id','$cd','1')";
	$res=$connect->query($req);
	header("Location:membre.php");
?>