<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>tchat</title>
        <link rel="stylesheet" href="authentification.css?t=<?php echo time();?>"/> 
	</head>
    <body>
	    <div id="div1">
		    <p id="par1">
	        <h1 id='h1'>MamiTChat</h1>     
	        <h3 id='h3'><marquee>Vos amis vous attendent, authentifiez vous pour les rejoindre</marquee></h3>  
            </p>			
	        <form id="form" method="post" action="">
                <p id="aut">
     		        <label class="lab">Nom d'utilisateur</label><br>
                    <input  id="inp1" type="text" id='rech' name="userName" required="required"/>
			    </p>
			    <p>
			        <label class="lab">Mot de passe</label><br>
                    <input id="inp2" type="text" name="mdpAut"required="required"/>
                </p>
				<p>
                    <input id="sub" type="submit" value="connexion"/>
                </p>
            </form>
		    <p id='par3'><span>Vous n'avez pas de compte?</span> <a href="inscription1NP.php">S'inscrire?</a></p> 
        </div>		
	</body>
	<?php
	    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
		if($connect){
			$id=null;
		    if(isset($_POST['userName']) AND isset($_POST['mdpAut'])){
				$userName=$_POST['userName'];
				$mdpAut=$_POST['mdpAut'];
		        $req="SELECT idmbre,login,password FROM membre";
				$res=$connect->query($req);
				if($res){
					while($lign=$res->fetch()){
						$idc=$lign['idmbre'];
						if($lign['login']==$userName AND $lign['password']==$mdpAut){
							$reqs="UPDATE membre SET statut='1' WHERE idmbre=$idc";
				            $resS=$connect->query($reqs);
							header("Location:accueil.php");
						    $_SESSION['idmbre']=$lign['idmbre'];
							break;
						}
						else{
							echo'no';
							header("Location:authentification.php");
						    // echo 'Le Login ou le mot de passe saisi est incorrect';
						}
					}					
				}
			}			
		}
		else
			echo 'connexion à la BD non établie';
?>
	<script  ></script>
</html>
		

