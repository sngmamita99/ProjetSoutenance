<?php
	session_start();
?>
<?php
    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	if($connect){			
	    if(isset($_POST['lg']) AND isset($_POST['mdp'])){
	     	$lg=$_POST['lg'];
			$mdp=$_POST['mdp'];
			$idmbre=$_SESSION['idmbre'];
		    $req2="UPDATE membre SET login='$lg',password='$mdp' WHERE idmbre='$idmbre'";
			$res=$connect->query($req2);
		 }
	}
	else
		echo 'connexion à la BD non établie';
	
?>	


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>tchat</title>
        <link rel="stylesheet" href="authentification.css?t=<?php echo time();?>"/> 
	</head>
    <body>
	    
	    <div id="div1">
		    <p id="par1">
	        <h1 id='h1'>MamiChat</h1>     
	        <h3 id='h3'><marquee>Votre numéro de téléphone et votre adresse email?</marquee></h3>  
            </p>			
	        <form id="form" method="post" action="inscription4GDN.php" >
			    <p>
			        <label class="lab">Numéro de téléphone</label><br>
                    <input id="inp2" type="text" name="numtel" value="+221 "/>
                </p>
				<p id="aut">
     		        <label class="lab">Adresse email</label><br>
                    <input  id="inp1" type="text" id='rech' name="email"/>
			    </p>
				<p>
                    <input id="sub" type="submit" value="suivant"/>
                </p>
            </form>
			<a href="inscription2LM.php"><button id="btn" value="suivant">RETOUR</button></a>
        </div>		
	</body>
	<script  ></script>
</html>
		

