<?php 
    session_start();
	$connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	if($connect){
		$id=$_SESSION['idmbre'];
		$req1="SELECT nom,penom FROM membre WHERE idmbre='$id'";
		$res1=$connect->query($req1);
		$req2="select DISTINCT demandeur,cible,nom,penom,urlpp from amitié a, membre m WHERE (a.demandeur='$id' AND a.etat='1' AND m.idmbre<>'$id' AND a.cible=m.idmbre) OR (a.cible='$id' AND a.etat='1' AND m.idmbre<>'$id' AND a.demandeur=m.idmbre)";
		$res2=$connect->query($req2);
		if($res1){
			while($ligne=$res1->fetch())
			    echo 'Vous '.$ligne['penom'].' '.$ligne['nom'];
		}
		echo '<table>';
		while($lign=$res2->fetch()){
		    $n=$lign['nom'];
		    $pn=$lign['penom'];
			$pp=$lign['urlpp'];
            echo '<tr><td><img src='."$pp".'/>';
            
            echo $pn.' '.$n;
            echo '</td></tr>';
            		
        }
        // $req3="select idmbre from amitié a, membre m WHERE (a.demandeur='$id' AND a.etat='1' AND m.idmbre<>'$id' AND a.cible=m.idmbre) OR (a.cible='$id' AND a.etat='1' AND m.idmbre<>'$id' AND a.demandeur=m.idmbre)";		
		// $res3=$connect->query($req3);
		// $_SESSION['idmbre']=$res3->fetch();	
        // while($_SESSION['idmbre'])
            // echo $_SESSION['idmbre'];			
	}
	
	// SELECT demandeur,cible,nom,prenom,urlpp from 
    // ((select demandeur,cible,nom,prenom from amitié a,membre m where a.demandeur='$_SESSION['idmbre']' or a.cible='$_SESSION['idmbre'])
	// r,photoprofil p where r.demandeur=p.idmbre or r.cible=p.idmbre);
?>
