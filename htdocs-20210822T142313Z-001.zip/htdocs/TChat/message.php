<?php
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
	    <meta charset="utf-8" />
		<title>MamiTChat</title>
	    <link rel="stylesheet" href="accueil.css"/> 
	</head>
	<nav>
	    <ul>
		    <li>
			    <a>Accueil</a>
			</li>
			<li>
			    <a>Discutions</a>
			</li>
			<li>
			    <a>MamiTChaters</a>
			</li>
			<li>
			    <a>Friends MamiTChaters</a>
			</li>
		</ul>
	</nav>
	<body>   
		<div id="DIV">
		    <div id="div1">
			    <h1 id='h1'>MamiTChat</h1>
				<p id="p1"></p>
				
			</div>
	        <div id="div2"></div>
		</div>			   
	</body>
    <script  src="accueil.js"></script>
</html>
		

