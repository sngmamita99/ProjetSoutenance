<?php
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
	    <meta charset="utf-8" />
		<title>MamiTChat</title>
	    <link rel="stylesheet" href="membre.css?t=<?php echo time();?>"/> 
	</head>
	<nav>
	 
	    <h1 id='h1'>MamiTChat</h1>
		<p id="p1">
		    <?php
		    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
		    $id=$_SESSION['idmbre'];
		    $req1="SELECT nom,penom,genre FROM membre WHERE idmbre='$id'";
		    $res1=$connect->query($req1);
			if($res1){
			    while($ligne=$res1->fetch())
					if($ligne['genre']=="Homme")
			            echo $ligne['penom'].' '.$ligne['nom'].'<br><span>connecté</span>';
					else
						echo $ligne['penom'].' '.$ligne['nom'].'<br><span>connectée</span>';
		    }          
		 ?>
		</p>   		
      <p id="p2">  		
	    <ul>
		    <li>
			    <a href="accueil.php">Accueil</a>
			</li>
			
			<li>
			    <a href="membre.php">Voir les MamiTChaters</a>
			</li>
			<li>
			    <a href="amis.php">Mes Ami(e)s MamiTChaters</a>
			</li>
		</ul>
		</p> 
	</nav>
	<body>   
		<div id="DIV">
		    <div id="div1">
				<?php 
	                $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	                if($connect){		            
		                $req2="select idmbre,nom,penom,genre,urlpp from membre WHERE idmbre<> '$id' ORDER BY nom";
		                $res2=$connect->query($req2);
		                if($res2){
			                while($ligne=$res2->fetch()){
							    $pp=$ligne['urlpp'];	
                                $cdd=$ligne['idmbre'];							
			                    echo '<p id="pinp">';
								    echo '<img src='."$pp".'></img> ';
									echo '<span id="pph">'.$ligne['penom'].' '.$ligne['nom'];
									$req3="select * from amitié where (demandeur='$id' and cible='$cdd' and etat='1') or (demandeur='$cdd' and cible='$id' and etat='1')";
		                            $res3=$connect->query($req3);
									$lign=$res3->fetch();
									    // if(($lig['demandeur']==$id && $lig['cible']==$cdd && $lig['etat']==1) || ($lig['demandeur']==$cdd && $lig['cible']==$id && $lig['etat']==1))
									    if($lign)
									        echo '<span id="btna">vous êtes ami</span></p>';
                                     	else									
									        echo '<a href="traiterDemande.php?cdd='.$cdd.'"><button id="btn">Demande d\'amitié</button></a></p>';
										
							}
		                }           		
                    }        		
	   	
                ?>		
			</div>
		</div>			   
	</body>
    <script  src="membre.js"></script>
	<script  src="JQueryJS.js"></script>
</html>
		

