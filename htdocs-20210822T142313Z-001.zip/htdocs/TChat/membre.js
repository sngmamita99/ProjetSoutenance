var mbr=document.getElementById('btn');
$("button").one("click",function(){
	$(this).html('Demande envoyée');
});