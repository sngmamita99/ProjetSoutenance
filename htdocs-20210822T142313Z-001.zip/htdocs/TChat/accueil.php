<?php
	session_start();
	
?>
<?php
    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	if($connect){			
		$idmbre=$_SESSION['idmbre'];
		if(isset($_FILES['photo'])){               
            $extensions_ok = array('jpg','jpeg','gif','png');
            $extension_fichier = strtolower( substr(strrchr($_FILES['photo']['name'], '.'),1));
            if ( in_array($extension_fichier, $extensions_ok) ){
                echo "<p>Extension correcte du fichier</p>"; 
            }
                $dhc=date("dmy_his",time());
                $fic="mesphotos/".$dhc."_".$_FILES['photo']['name'];
                $result=move_uploaded_file($_FILES['photo']['tmp_name'],$fic);
                if($result){
                    echo "<p>transfert du fichier reussi</p>";
                }
                $url="mesphotos/".$dhc."_".$_FILES['photo']['name'];                
		        $req2="UPDATE membre SET urlpp='$url' WHERE idmbre='$idmbre'";
			    $res=$connect->query($req2);
		}	
				// echo '<table>';
		        // while($lign=$res->fetch()){
		    // $n=$lign['nom'];
		    // $pn=$lign['penom'];
			    // $pp=$lign['urlpp'];
            // echo '<tr><td><img src='."$pp".'/>';
            
            // echo $pn.' '.$n;
            // echo '</td></tr>';
            		
        // }	
        // echo '</table>';
			// }
			// else
				// echo 'no';
	}
	else
		echo 'connexion à la BD non établie';
	
?>
<!DOCTYPE html>
<html>
	<head>
	    <meta charset="utf-8" />
		<title>MamiTChat</title>
	    <link rel="stylesheet" href="accueil.css?t=<?php echo time();?>"/> 
	</head>
	<body>   
		<div id="div1">
		<h1 id='h1'>MamiTChat</h1>
		<?php 
		    $connect=new PDO("mysql:host=localhost;port=3306;dbname=mamitchat","root","");
	        if($connect){
		    $id=$_SESSION['idmbre'];
		    $req1="SELECT nom,penom FROM membre WHERE idmbre='$id'";
		    $res1=$connect->query($req1);
			if($res1){
			while($ligne=$res1->fetch())
			    echo '<p id="pbv"><marquee>Bienvenue '.$ligne['penom'].' '.$ligne['nom'].'</marquee></p>';
			}
		}
		?>
		<nav>
	    <ul>
		    <li>
			    <a href="accueil.php">Accueil</a>
			</li>
			<li>
			    <a href="membre.php">Voir les MamiTChaters</a>
			</li>
			<li>
			    <a href="amis.php">Mes Ami(e)s MamiTChaters</a>
			</li>
		</ul>
	     </nav>
				
	        </div>
					   
	</body>
    <script  ></script>
</html>
		

